package edu.byu.cs.tweeter.presenter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;

import edu.byu.cs.tweeter.model.domain.Status;
import edu.byu.cs.tweeter.model.domain.User;
import edu.byu.cs.tweeter.model.net.TweeterRemoteException;
import edu.byu.cs.tweeter.model.service.PostServiceProxy;
import edu.byu.cs.tweeter.model.service.request.PostRequest;
import edu.byu.cs.tweeter.model.service.response.PostResponse;

public class PostPresenterTest {
    private PostRequest request;
    private PostResponse response;
    private PostServiceProxy mockPostService;
    private PostPresenter presenter;

    @BeforeEach
    public void setup() throws IOException, TweeterRemoteException
    {
        User currentUser = new User("FirstName", "LastName", null);

        User resultUser1 = new User("FirstName1", "LastName1",
                "https://faculty.cs.byu.edu/~jwilkerson/cs340/tweeter/images/donald_duck.png");
        User resultUser2 = new User("FirstName2", "LastName2",
                "https://faculty.cs.byu.edu/~jwilkerson/cs340/tweeter/images/daisy_duck.png");
        User resultUser3 = new User("FirstName3", "LastName3",
                "https://faculty.cs.byu.edu/~jwilkerson/cs340/tweeter/images/daisy_duck.png");

        Status status1 = new Status("hello @James how are you? https://google.com", resultUser1, "Jan 1, 2021");


        request = new PostRequest(status1);
        response = new PostResponse(true, "successfully posted");

        // Create a mock PostService
        mockPostService = Mockito.mock(PostServiceProxy.class);
        Mockito.when(mockPostService.updatePostServer(request)).thenReturn(response);

        // Wrap a PostPresenter in a spy that will use the mock service.
        presenter = Mockito.spy(new PostPresenter(new PostPresenter.View() {}));
        Mockito.when(presenter.getPostService()).thenReturn(mockPostService);
    }

    @Test
    public void testGetPost_returnsServiceResult() throws IOException, TweeterRemoteException
    {
        Mockito.when(mockPostService.updatePostServer(request)).thenReturn(response);

        // Assert that the presenter returns the same response as the service (it doesn't do
        // anything else, so there's nothing else to test).
        Assertions.assertEquals(response, presenter.sendPostRequest(request));
    }

    @Test
    public void testGetPost_serviceThrowsIOException_presenterThrowsIOException() throws IOException, TweeterRemoteException
    {
        Mockito.when(mockPostService.updatePostServer(request)).thenThrow(new IOException());

        Assertions.assertThrows(IOException.class, () -> {
            presenter.sendPostRequest(request);
        });
    }
}
